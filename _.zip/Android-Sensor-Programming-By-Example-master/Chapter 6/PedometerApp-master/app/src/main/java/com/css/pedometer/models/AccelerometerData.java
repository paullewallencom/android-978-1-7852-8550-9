package com.css.pedometer.models;


public class AccelerometerData {

    public double value;
    public float x;
    public float y;
    public float z;
    public long time;
    public boolean isRealPeak = true;
}
