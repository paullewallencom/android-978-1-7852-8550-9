package com.css.pedometer.models;

public class DateStepsModel {

	public String mDate;
	public int mStepCount;
}
