# CompassShakeFingerPrintUtility
A Utility Application that show the usages of the following API.  
1. Compass using Orientation APIs and Orientation Sensor.  
2. Detect Shaking of Phone using Accelerometer.  
3. Using FingerPrint Sensor.
