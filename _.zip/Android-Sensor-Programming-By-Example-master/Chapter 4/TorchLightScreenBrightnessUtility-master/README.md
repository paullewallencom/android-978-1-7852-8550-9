# TorchLightScreenBrightnessUtility
Explains the proximity and light sensors.

Following are the high level requirements for the automatic torch light application.  
1.	Create an Android activity to process the proximity sensor values.  
2.	Whenever any object come close to phone (proximity sensor gives near value), turn on the flashlight and whenever that object goes away from the phone (proximity sensor give far value), then turn off the flashlight.   
3.	Create an Android activity to process the light sensor values.  
4.	Whenever the phone goes in any dark area, increase the screen brightness of the phone and when the phone goes back to lighted area and then decrease the screen brightness of the phone.
